import json

def handler(event, context):
    path = event.get('path', '')
    
    if 'server' in path:
        body = {"m.server": "matrix.todf.mom:443"}
    else:
        body = {
            "m.homeserver": {"base_url": "https://matrix.todf.mom"},
            "org.matrix.msc4143.rtc_foci": [{"type": "livekit", "livekit_service_url": "https://livekit-jwt.call.matrix.org"}],
            "im.vector.riot.jitsi": {"preferredDomain": "meet.jit.si"}
        }

    return {
        "statusCode": 200,
        "statusDescription": "200 OK",
        "isBase64Encoded": False,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type"
        },
        "body": json.dumps(body)
    }
